//
//  ViewController.swift
//  iTunesRequestList_CM
//
//  Created by Germán Santos Jaimes on 10/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var tracks: [Track] = []
    @IBOutlet weak var tabla: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabla.dataSource = self
        getTracks()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tracks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        let trackTemp = tracks[indexPath.row]
        
        cell.textLabel!.text = trackTemp.trackName
        let url = URL(string: trackTemp.artworkUrl100)
        cell.imageView?.downloadImage(from: url!)
        
        return cell
    }
    
    func getTracks(){
        let url = URL(string: "https://itunes.apple.com/search?term=metallica")
        
        let jsonDecoder = JSONDecoder()
        
        let task = URLSession.shared.dataTask(with: url!){ (data, response, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            
            if let data = data, let contenido = try? jsonDecoder.decode(Resultado.self, from: data){
                var tracksList = contenido.results
                for track in tracksList{
                    print(track.trackName)
                    
                    self.tracks.append(track)
                }
                DispatchQueue.main.async { // Correct
                    self.tabla.reloadData()
                }

            }
        }
        
        task.resume()
    }
    
    
    
}

