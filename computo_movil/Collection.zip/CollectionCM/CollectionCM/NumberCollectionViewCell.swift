//
//  NumberCollectionViewCell.swift
//  CollectionCM
//
//  Created by Germán Santos Jaimes on 9/18/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class NumberCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var numero: UILabel!
}
