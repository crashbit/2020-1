//
//  ViewController.swift
//  CollectionCM
//
//  Created by Germán Santos Jaimes on 9/18/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var coleccion: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        coleccion.dataSource = self

    }
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "item", for: indexPath) as! NumberCollectionViewCell
        
        cell.backgroundColor = .red
        cell.numero.text = "\(indexPath.item)"
        
        return cell
    }
}

