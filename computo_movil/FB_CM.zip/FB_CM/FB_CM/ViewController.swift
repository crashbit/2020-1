//
//  ViewController.swift
//  FB_CM
//
//  Created by Germán Santos Jaimes on 10/28/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var emailUser: UITextField!
    
    @IBOutlet weak var passwordUser: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func crearCuenta(_ sender: UIButton) {
        
        guard let email = emailUser.text, email != "", let password = passwordUser.text, password != "" else{
            return
        }
        
        Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            print("Usuario autenticado")
            
        }
        
//        Auth.auth().createUser(withEmail: email, password: password) { (user, error) in
//            if let error = error{
//                print(error.localizedDescription)
//                return
//            }
//            print(user?.user.email)
//        }
        
        
        performSegue(withIdentifier: "autenticado", sender: self)
    }
    
}

