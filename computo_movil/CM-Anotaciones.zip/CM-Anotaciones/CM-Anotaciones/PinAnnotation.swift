//
//  PinAnnotation.swift
//  CM-Anotaciones
//
//  Created by Germán Santos Jaimes on 10/7/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class PinAnnotation: MKPointAnnotation {
    var imageURL: String!
}
