//
//  ViewController.swift
//  FBDB_CM
//
//  Created by Germán Santos Jaimes on 10/30/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseFirestore

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var nombreUser: UITextField!
    @IBOutlet weak var apellidoUser: UITextField!
    @IBOutlet weak var edadUser: UITextField!
    @IBOutlet weak var tabla: UITableView!
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    var datosFB: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabla.dataSource = self
        
        getRef = Firestore.firestore()
        
        getAlumnos()
    }


    @IBAction func agregar(_ sender: UIButton) {
        
        var datos: [String: Any] = ["nombre": nombreUser.text, "apellido": apellidoUser.text, "edad": edadUser.text]
        
        ref = getRef.collection("alumno").addDocument(data: datos, completion: { (error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }else{
                print("Se guardaron los datos")
            }
        })
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datosFB.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        cell.textLabel!.text = datosFB[indexPath.row]
        return cell
    }
    
    func getAlumnos(){
//        getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("alumno").addSnapshotListener{ (querySnapshot, error) in
        
            if let error = error{
                print(error.localizedDescription)
                return
            }
            
            self.datosFB.removeAll()
            
            for document in querySnapshot!.documents{
                let id = document.documentID
                
                let values = document.data()
                let nombre = values["nombre"] as? String ?? "No tiene info"
                
                self.datosFB.append(nombre)
            }
            self.tabla.reloadData()
        }
    }
    
    
}

