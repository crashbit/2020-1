//
//  ViewController.swift
//  CM-Direcciones
//
//  Created by Germán Santos Jaimes on 10/9/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapa: MKMapView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapa.delegate = self
        
        let inicioLocation = CLLocationCoordinate2D(latitude: 19.3272501, longitude: -99.1825469)
        
        let destinoLocation = CLLocationCoordinate2D(latitude: 19.3248272, longitude: -99.1847808)
        
        let inicioPin = Direccion(title: "Ingenería", subtitle: "Anexo", coordinate: inicioLocation)
        
        let destinoPin = Direccion(title: "Contaduria", subtitle: "Algun lugar", coordinate: destinoLocation)
        
        mapa.addAnnotation(inicioPin)
        mapa.addAnnotation(destinoPin)
        
        // Agregamos placemarks
        let inicioPlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: destinoLocation)
        
        let directionRequest = MKDirections.Request()
        
        directionRequest.source = MKMapItem(placemark: inicioPlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        
        directionRequest.transportType = .walking
        
        let directions = MKDirections(request: directionRequest)
        
        directions.calculate { (response, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            
            guard let directionResponse = response else{
                return
            }
            
            let ruta = directionResponse.routes.first
            self.mapa.addOverlay(ruta!.polyline)
            
            let rect = ruta?.polyline.boundingMapRect
            self.mapa.setRegion(MKCoordinateRegion(rect!), animated: true)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let linea = MKPolylineRenderer(overlay: overlay)
        linea.strokeColor = .blue
        linea.lineWidth = 4.0
        return linea
    }
    
    
    
}

