//
//  ViewController.swift
//  PasoDeDatos
//
//  Created by Germán Santos Jaimes on 8/28/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var jerry = Alumno(nombre: "Jerrys")
    var julioMalo = Profesor(nombre: "Julio Malo")
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("Vista dos fuera...")
        print(julioMalo.nombre)
        print(jerry.nombre)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondView = segue.destination as! SecondViewController
        secondView.dato = "Hola mundo desde vista 1"
        secondView.jerryVistaUno = jerry
        secondView.profesorVistaUno = julioMalo
        secondView.vista1 = self
    }
}

