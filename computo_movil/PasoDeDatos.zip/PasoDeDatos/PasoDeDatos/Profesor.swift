//
//  Profesor.swift
//  PasoDeDatos
//
//  Created by Germán Santos Jaimes on 8/28/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class Profesor{
    var nombre: String
    init(nombre: String){
        self.nombre = nombre
    }
}
