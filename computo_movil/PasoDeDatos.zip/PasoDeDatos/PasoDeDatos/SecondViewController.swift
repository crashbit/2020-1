//
//  SecondViewController.swift
//  PasoDeDatos
//
//  Created by Germán Santos Jaimes on 8/28/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var dato: String!
    var jerryVistaUno: Alumno!
    var profesorVistaUno: Profesor!
    
    var vista1: ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .cyan
        
        print(dato!)
        print(jerryVistaUno.nombre)
        print(profesorVistaUno.nombre)
        
    }
    
    @IBAction func cerrar(_ sender: UIButton){
        
        profesorVistaUno.nombre = "Julio"
        jerryVistaUno.nombre = "Gerardo"
        vista1.jerry.nombre = "Gerardo el biomedico"
        
        //dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
        
    }

    

}
