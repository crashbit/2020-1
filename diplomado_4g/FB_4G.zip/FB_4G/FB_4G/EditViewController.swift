//
//  EditViewController.swift
//  FB_4G
//
//  Created by Germán Santos Jaimes on 9/7/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import FirebaseFirestore

class EditViewController: UIViewController {
    
    @IBOutlet weak var producto: UITextField!
    @IBOutlet weak var precio: UITextField!
    
    var datosProducto: Producto!

    var ref: DocumentReference!
    var getRef: Firestore!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let id = datosProducto.id
        
        ref = Firestore.firestore().collection("productos").document(id)

        producto.text = datosProducto.nombre
        precio.text = datosProducto.precio
    }
    
    @IBAction func aceptar(_ sender: UIButton){
        
        let values: [String: Any] = ["nombre": producto.text, "precio": precio.text]
        
        ref.setData(values) { (error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                print("Datos actualizados")
            }
        }
        
        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func cancelar(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
