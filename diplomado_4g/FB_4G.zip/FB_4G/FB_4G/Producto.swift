//
//  Producto.swift
//  FB_4G
//
//  Created by Germán Santos Jaimes on 9/7/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

struct Producto{
    var nombre: String
    var precio: String
    var id: String
}

