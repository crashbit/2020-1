//
//  User.swift
//  Segues
//
//  Created by Germán Santos Jaimes on 8/24/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

struct User{
    var email: String
    var user: String
    var password: String
}
