//
//  ViewController.swift
//  JerrysProject
//
//  Created by Germán Santos Jaimes on 9/12/19.
//  Copyright © 2019 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var toys:[Toy] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        getPlist()
        
        print(toys)
        
    }
    
    func getPlist(){
        let path = Bundle.main.path(forResource: "ToysCatalog", ofType: "plist")!
        let dict = NSDictionary(contentsOfFile: path)
        toys.removeAll()
        for item in dict! as! [String: Any]{
            
            let dato = item.value as! [String : Any]
            var name = dato["name"]! as! String
            var price = dato["price"]! as! Int
            var asset = dato["asset"]! as! String
            var stock = dato["stock"]! as! Int
            let toy = Toy(name: name, price: String(price), asset: asset, stock: String(stock))
            toys.append(toy)
        }
    }
    
   

}

