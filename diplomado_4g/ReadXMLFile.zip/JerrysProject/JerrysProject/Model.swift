//
//  Model.swift
//  JerrysProject
//
//  Created by Germán Santos Jaimes on 9/12/19.
//  Copyright © 2019 Germán Santos Jaimes. All rights reserved.
//

import UIKit

struct Toy{
    var name: String
    var price: String
    var asset: String
    var stock: String
}
