//
//  Vista3.swift
//  Programatic
//
//  Created by Germán Santos Jaimes on 9/21/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class Vista3: UIViewController{
    
    var valorRecibido: String!
    var vista1 : AlumnoTableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(valorRecibido)
        vista1.valorRecibidoDeLaTres = "Saludos desde la tres"
        
    }
    
    
    
}
