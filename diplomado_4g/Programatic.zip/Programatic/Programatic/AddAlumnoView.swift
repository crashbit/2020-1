//
//  AddAlumnoView.swift
//  Programatic
//
//  Created by Germán Santos Jaimes on 9/21/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class AddAlumnoView: UIViewController{
    
    override func viewDidLoad() {
        navigationItem.title = "Agregar Alumno"
        print("vista add alumno")
        
        view.backgroundColor = .azulMarino
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Cancelar", style: .plain, target: self, action: #selector(cancel))
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Guardar", style: .plain, target: self, action: #selector(save))
        
    }
    
    @objc func cancel(){
        print("cancelar")
        navigationController?.popViewController(animated: true)
    }
    
    @objc func save(){
        print("guardar")
    }
}
