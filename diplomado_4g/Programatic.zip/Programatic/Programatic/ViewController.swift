//
//  ViewController.swift
//  Programatic
//
//  Created by Germán Santos Jaimes on 9/21/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let boton : UIButton = {
       let btn = UIButton(type: .system)
        
        btn.setTitle("Click please", for: .normal)
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        btn.addTarget(self, action: #selector(clicked), for: .touchUpInside)
      
        btn.backgroundColor = .red
        return btn
    }()
    
    let etiqueta: UILabel = {
       let label = UILabel()
        label.text = "Hola mundo"
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = UIFont(name: "Arial", size: 20)
        label.backgroundColor = .red
        
        return label
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .cyan
        view.addSubview(boton)
        view.addSubview(etiqueta)
        
        boton.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        boton.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        boton.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        boton.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        etiqueta.topAnchor.constraint(equalTo: boton.bottomAnchor, constant: 20).isActive = true

        etiqueta.heightAnchor.constraint(equalToConstant: 100).isActive = true
        etiqueta.widthAnchor.constraint(equalToConstant: 200).isActive = true
        
    }

    @objc func clicked(){
        print("click, click")
    }

}

