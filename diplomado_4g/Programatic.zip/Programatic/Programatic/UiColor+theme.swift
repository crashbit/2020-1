//
//  UiColor+theme.swift
//  Programatic
//
//  Created by Germán Santos Jaimes on 9/21/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

extension UIColor{
    
    static let azulMarino = UIColor(red: 9/255, green: 45/255, blue: 64/255, alpha: 1)
    
    static let azulClaro = UIColor(red: 218/255, green: 235/255, blue: 243/255, alpha: 1)
    
}
