//
//  AlumnosTableView.swift
//  Programatic
//
//  Created by Germán Santos Jaimes on 9/21/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class AlumnoTableView: UITableViewController{
    
    var valorRecibidoDeLaTres: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Lista de alumnos"
        
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.barTintColor = .red
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]

        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.isTranslucent = false
        
        tableView.backgroundColor = .azulMarino
        
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "celda")
        
        tableView.tableFooterView = UIView()
        tableView.separatorColor = .azulMarino
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Agregar", style: .plain, target: self, action: #selector(addAlumno))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print(valorRecibidoDeLaTres)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.backgroundColor = .azulClaro
        
        cell.textLabel?.text = "alumno"
        return cell
        
    }
    
    @objc func addAlumno(){
        print("Add Alumno")
        
        let addAlumno = AddAlumnoView()
        
        //present(addAlumno, animated: true, completion: nil)
//        navigationController?.pushViewController(addAlumno, animated: true)
        
        let vistaTres = Vista3()
        vistaTres.valorRecibido = "hola desde la vista 1"
        vistaTres.vista1 = self
        present(vistaTres, animated: true, completion: nil)
        
    }
    
}
