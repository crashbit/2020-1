//
//  Pelicula.swift
//  MPOO-Collection
//
//  Created by Germán Santos Jaimes on 9/11/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

struct Pelicula{
    var poster: String
    var titulo: String
}
