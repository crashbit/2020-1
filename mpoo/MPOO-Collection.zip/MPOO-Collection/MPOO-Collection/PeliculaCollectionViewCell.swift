//
//  PeliculaCollectionViewCell.swift
//  MPOO-Collection
//
//  Created by Germán Santos Jaimes on 9/11/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class PeliculaCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var poster: UIImageView!
    @IBOutlet weak var nombre: UILabel!
    
}
