//
//  ViewController.swift
//  MPOO-Collection
//
//  Created by Germán Santos Jaimes on 9/11/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {
    
    var peliculas:[Pelicula] = [
        Pelicula(poster: "gato", titulo: "el gato"),
        Pelicula(poster: "poster", titulo: "pelicula")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return peliculas.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cuadrito", for: indexPath) as! PeliculaCollectionViewCell
        
        cell.nombre.text = peliculas[indexPath.item].titulo
        cell.poster.image = UIImage(named: peliculas[indexPath.item].poster)
        
        return cell
    }
    

}

