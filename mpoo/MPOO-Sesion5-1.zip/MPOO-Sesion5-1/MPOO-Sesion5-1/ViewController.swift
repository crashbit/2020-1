//
//  ViewController.swift
//  MPOO-Sesion5-1
//
//  Created by Germán Santos Jaimes on 8/19/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var slider: UISlider!
    
    
    @IBOutlet weak var portaRetrato: UIImageView!
    
    var gatos:[String] = ["gato1", "gato2", "gato3", "gato4", "gato5"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        portaRetrato.image = UIImage(named: gatos[2])
    }
    
    
    @IBAction func cambiar(_ sender: UISlider) {
        
        var valor = slider.value * 100.0
        
        switch valor{
        case 0...20:
            portaRetrato.image = UIImage(named: gatos[0])
        case 21...40:
            portaRetrato.image = UIImage(named: gatos[1])
        case 41...60:
            portaRetrato.image = UIImage(named: gatos[2])
        case 61...80:
            portaRetrato.image = UIImage(named: gatos[3])
        case 81...100:
            portaRetrato.image = UIImage(named: gatos[4])
        default:
            print()
        }
        
        
        
    }
    

}

