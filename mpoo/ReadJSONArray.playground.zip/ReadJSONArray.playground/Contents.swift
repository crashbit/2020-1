import UIKit

struct Alumno: Codable{
    var nombre: String
    var edad: Int
}


let path = Bundle.main.path(forResource: "datos", ofType: "json")

let jsonData = NSData(contentsOfFile: path!)

let alumnos = try! JSONDecoder().decode([Alumno].self, from: jsonData! as Data)

for alumno in alumnos{
    print(alumno.nombre, alumno.edad)
}


