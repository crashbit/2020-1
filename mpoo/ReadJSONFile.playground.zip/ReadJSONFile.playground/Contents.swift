import UIKit

struct User: Codable {
    var first_name:String
    var last_name:String
    var country:String
}

let path = Bundle.main.path(forResource: "data", ofType: "json")

let jsonData = NSData(contentsOfFile: path!)

let jsonString = try! String(contentsOfFile: path!, encoding: .utf8)

let user = try! JSONDecoder().decode(User.self, from: jsonData! as Data)

print(user.last_name)
