//
//  Model.swift
//  TableTracksItunes_MPOO
//
//  Created by Germán Santos Jaimes on 10/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

struct Resultados: Codable{
    var resultCount: Int
    var results: [Track]
}

struct Track: Codable{
    var trackName: String
    var collectionName: String
}
