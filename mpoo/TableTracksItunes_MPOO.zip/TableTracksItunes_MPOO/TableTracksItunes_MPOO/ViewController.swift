//
//  ViewController.swift
//  TableTracksItunes_MPOO
//
//  Created by Germán Santos Jaimes on 10/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UISearchBarDelegate {
    
    var trackList: [Track] = []
    @IBOutlet weak var tabla: UITableView!

    let searchBarController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabla.dataSource = self
        //getTracks(artista: "muse")
        
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.searchController = searchBarController
        navigationItem.hidesSearchBarWhenScrolling = false
        navigationItem.title = "Lista de tracks"
        
        searchBarController.searchBar.delegate = self
        searchBarController.dimsBackgroundDuringPresentation = false
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trackList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        let track = trackList[indexPath.row]
        cell.textLabel!.text = "\(track.trackName) - \(track.collectionName)"
        
        
        return cell
    }
    
    func getTracks(artista: String){
        let url = URL(string: "https://itunes.apple.com/search?term=\(artista)")
        let jsonDecoder = JSONDecoder()
        
        
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            
            if let datos = data, let contenido = try? jsonDecoder.decode(Resultados.self, from: datos) {
                let tracksListTemp = contenido.results
                self.trackList.removeAll()
                for track in tracksListTemp{
                    print(track.trackName)
                    self.trackList.append(track)
                }
                
                DispatchQueue.main.async { // Correct
                    self.tabla.reloadData()
                }
                
            }
        }
        
        task.resume()

    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count > 4 {
                getTracks(artista: searchText)
        }
    }


}

