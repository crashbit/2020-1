import UIKit
import PlaygroundSupport

struct Resultados: Codable{
    var resultCount: Int
    var results: [Track]
}

struct Track: Codable{
    var trackName: String
}

let url = URL(string: "https://itunes.apple.com/search?term=muse")
let jsonDecoder = JSONDecoder()


let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
    if let error = error{
        print(error.localizedDescription)
        return
    }
    
    if let datos = data, let contenido = try? jsonDecoder.decode(Resultados.self, from: datos) {
        let tracksList = contenido.results
        for track in tracksList{
            print(track.trackName)
        }
    }
}

task.resume()

PlaygroundPage.current.needsIndefiniteExecution = true
