//
//  ViewController.swift
//  DownLoadImage
//
//  Created by Germán Santos Jaimes on 12/2/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseUI
import MobileCoreServices


class ViewController: UIViewController {

    
    @IBOutlet weak var imagen: UIImageView!
    
    var getRef: Firestore!
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        let storageReference = Storage.storage().reference()
        let photoDownload = storageReference.child("/Archivos/coches.jpg")
        
        let placeHolder = UIImage(named: "backup")
        
        imagen.sd_setImage(with: photoDownload, placeholderImage: placeHolder)
        
        photoDownload.downloadURL { (url, error) in
            if let error = error{
                print("hubo un error")
                print(error.localizedDescription)
            }else{
                print("url: \(String(describing: url!))")
                
            }
        }
    }
}

