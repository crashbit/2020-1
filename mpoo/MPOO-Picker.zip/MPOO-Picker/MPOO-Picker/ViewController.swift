//
//  ViewController.swift
//  MPOO-Picker
//
//  Created by Germán Santos Jaimes on 9/23/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var picker: UIPickerView!
    
    var datos = [
        ["Ingeniería", "Quimica", "Contaduria", "Medicina", "Ciencias", "Filosofía", "Aragón"],
        ["Malo", "Regular", "Bueno", "Muy bueno"]
    ]
    
    var escuela: String = ""
    var valor : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.dataSource = self
        picker.delegate = self
        
        escuela = datos[0][0]
        valor  = datos[1][0]
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return datos.count
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return datos[component].count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return datos[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if component == 0{
            escuela = datos[0][row]
        }else{
            valor = datos[1][row]
        }
        
        print("La escuela \(escuela) tiene un valor de \(valor)")
    }
}

