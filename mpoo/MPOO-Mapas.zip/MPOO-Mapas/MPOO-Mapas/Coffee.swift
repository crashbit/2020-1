//
//  Coffee.swift
//  MPOO-Mapas
//
//  Created by Germán Santos Jaimes on 9/30/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class CoffeeAnotation: MKPointAnnotation{
    
    var imageURL: String!
    
}
