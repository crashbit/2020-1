//
//  ViewController.swift
//  MPOO-Mapas
//
//  Created by Germán Santos Jaimes on 9/30/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    var locationManager: CLLocationManager =  CLLocationManager()
    
    var latitud: CLLocationDegrees!
    var longitud: CLLocationDegrees!
    
    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        
        locationManager.startUpdatingLocation()
        
        mapa.delegate = self
        mapa.showsUserLocation = true
        
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.first!)
        
        if let localidad = locations.first{
            latitud = localidad.coordinate.latitude
            longitud = localidad.coordinate.longitude
            
            let localizacion = CLLocationCoordinate2DMake(latitud, longitud)
            let span = MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001)
            let region = MKCoordinateRegion(center: localizacion, span: span)
            
            mapa.setRegion(region, animated: true)
            mapa.mapType = .satellite
            
            
        }
        
    }
    
    @IBAction func agregarAnotacion(_ sender: UIButton){
        let anotacion = CoffeeAnotation()
        anotacion.coordinate = CLLocationCoordinate2D(latitude: 19.3275, longitude: -99.1823)
        
        anotacion.title = "iOS Dev Lab"
        anotacion.subtitle = "A nice place to work"
        anotacion.imageURL = "coffee-pin.png"
        mapa.addAnnotation(anotacion)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation{
            return nil
        }
        
        var coffeeAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "CoffeeAnotationView")
        
        if coffeeAnnotationView == nil{
            coffeeAnnotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "CoffeeAnotationView")
            coffeeAnnotationView?.canShowCallout = true
        } else {
            coffeeAnnotationView?.annotation = annotation
        }
        
        if let coffeeAnnotation = annotation as? CoffeeAnotation{
            coffeeAnnotationView?.image = UIImage(named: coffeeAnnotation.imageURL)
        }
        
        return coffeeAnnotationView
        
    }
    
    
}

